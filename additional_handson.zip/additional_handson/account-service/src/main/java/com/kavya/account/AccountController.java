package com.kavya.account.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/accounts")
public class AccountController {

    @GetMapping("/{id}")
    public String getAccountById(@PathVariable("id") int id) {
        return "Account Info for ID: " + id;
    }
}
