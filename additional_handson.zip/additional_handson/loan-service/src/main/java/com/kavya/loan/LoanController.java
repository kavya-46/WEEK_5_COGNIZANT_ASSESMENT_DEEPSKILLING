package com.kavya.loan;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/loans")
public class LoanController {

    @GetMapping("/{id}")
    public String getLoanById(@PathVariable("id") int id) {
        return "Loan Info for ID: " + id;
    }
}
